package com.example.aplikasimenumakanan;

public class Makanan {
    private int id_gambar;
    private String nama, harga;

    public Makanan(int id_gambar, String nama, String harga) {
        this.id_gambar = id_gambar;
        this.nama = nama;
        this.harga = harga;
    }

    public String getNama() { return nama; }
    public void setNama(String nama) { this.nama = nama; }
    public String getHarga() { return harga; }
    public void setHarga(String harga) { this.harga = harga; }
    public int getId_gambar() { return id_gambar; }
    public void setId_gambar(int id_gambar) { this.id_gambar = id_gambar; }
}