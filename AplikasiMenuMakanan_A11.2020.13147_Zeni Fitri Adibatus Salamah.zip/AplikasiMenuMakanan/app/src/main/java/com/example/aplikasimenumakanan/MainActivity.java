package com.example.aplikasimenumakanan;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import android.os.Bundle;
import android.view.View;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import android.widget.AbsListView;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recMakanan;
    private ArrayList<Makanan> listMakanan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recMakanan = findViewById(R.id.rec_makanan);
        initData();

        recMakanan.setAdapter(new MakananAdapter(listMakanan));
        recMakanan.setLayoutManager(new LinearLayoutManager(this));
    }
    private void initData(){
        this.listMakanan = new ArrayList<>();
        listMakanan.add(new Makanan(R.drawable.gado2,"Gado Gado","18.000"));
        listMakanan.add(new Makanan(R.drawable.gudeg,"Gudeg","15.000"));
        listMakanan.add(new Makanan(R.drawable.rendang,"Rendang","25.000"));
        listMakanan.add(new Makanan(R.drawable.sate,"Sate","20.000"));
        listMakanan.add(new Makanan(R.drawable.soto,"Soto","12.000"));
    }
}