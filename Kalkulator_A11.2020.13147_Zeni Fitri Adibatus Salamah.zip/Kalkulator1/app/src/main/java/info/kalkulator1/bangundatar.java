package info.kalkulator1;

public class bangundatar {
}
